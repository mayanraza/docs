# WhatsApp Components

Reusable UI elements for WhatsApp flows.

## Interactive List
Displays a list of options to the user.

## Buttons
Quick reply buttons (max 3).
